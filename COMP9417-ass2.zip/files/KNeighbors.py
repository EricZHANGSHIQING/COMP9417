from collections import defaultdict
import math
import numpy as np

class KNeighbors:
    def __init__(self, n_neighbors, weights, p, metric, normalization):
        assert isinstance(n_neighbors, int)
        assert weights in ('uniform', 'distance')
        assert metric in ('euclidean', 'manhattan', 'minkowski')
        assert normalization in ('none', 'zscore', 'minmax')
        self.n_neighbors = n_neighbors      # Number of neighbors to use for kneighbors queries.
        self.weights = weights              # Weight function used in prediction: 'uniform' or 'distance'
        self.p = p                          # Power parameter for the Minkowski metric.
        self.metric = metric                # The distance metric to use: 'euclidean', 'manhattan', or 'minkowski'
        self.normalization = normalization  # The normalization method to use: 'none', 'zscore', or 'minmax'
        self.normalization_params = {}      # Store the variables to be used during normalization

    # Fit the model using X as training data and y as target values
    def fit(self, X, y):
        assert isinstance(X, np.ndarray) and isinstance(y, np.ndarray)
        assert X.shape[0] == y.shape[0]
        if self.normalization == 'zscore':
            self.normalization_params['X_std']  = np.array([np.std(X[:,i]) for i in range(X.shape[1])])
            self.normalization_params['X_mean'] = np.array([np.mean(X[:,i]) for i in range(X.shape[1])])
        elif self.normalization == 'minmax':
            self.normalization_params['X_min']  = np.array([np.min(X[:,i]) for i in range(X.shape[1])])
            self.normalization_params['X_max']  = np.array([np.max(X[:,i]) for i in range(X.shape[1])])
        normalize = getattr(self, '_' + self.normalization)
        self.X = normalize(X)
        self.y = y

    # NORMALIZATION METHOD
    def _none(self, X):
        return X
    def _zscore(self, X):
        dividend = (X - self.normalization_params['X_mean'])
        divisor  = self.normalization_params['X_std']
        X_norm = np.divide(dividend, divisor, out=np.zeros_like(dividend), where=divisor!=0)
        return X_norm
    def _minmax(self, X):
        dividend = (X - self.normalization_params['X_min'])
        divisor  = (self.normalization_params['X_max'] - self.normalization_params['X_min'])
        X_norm = np.divide(dividend, divisor, out=np.zeros_like(dividend), where=divisor!=0)
        return X_norm

    # WEIGHT FUNCTIONS
    def _uniform(self, knn_distance):
        return [1.0 for _ in range(len(knn_distance))]
    def _distance(self, knn_distance):
        if knn_distance[-1] == knn_distance[0]:
            return [1.0 for _ in range(len(knn_distance))]
        else:
            weights = []
            for i in range(len(knn_distance)):
                weights.append((knn_distance[-1] - knn_distance[i]) / (knn_distance[-1] - knn_distance[0]))
            return weights

    # DISTANCE METRICS
    def _euclidean(self, x, y):
        return math.sqrt(np.sum((x - y)**2))
    def _manhattan(self, x, y):
        return np.sum(np.absolute(x - y))
    def _minkowski(self, x, y):
        return np.sum(np.absolute(x - y)**self.p)**(1 / self.p)

# Classifier implementing the k-nearest neighbors vote
class KNeighborsClassifier(KNeighbors):
    def __init__(self, n_neighbors=5, weights='uniform', p=2, metric='minkowski', normalization='none'):
        KNeighbors.__init__(self, n_neighbors, weights, p, metric, normalization)

    # Predict the class labels for the provided data
    def predict(self, X):
        assert isinstance(X, np.ndarray) and len(X.shape) == 2
        assert X.shape[1] == self.X.shape[1]
        get_weights  = getattr(self, '_' + self.weights)
        get_distance = getattr(self, '_' + self.metric)
        normalize    = getattr(self, '_' + self.normalization)
        X = normalize(X)
        y = np.array(['' for i in range(X.shape[0])])
        for i in range(X.shape[0]):
            distances = [0 for _ in range(self.X.shape[0])]
            for j in range(self.X.shape[0]):
                distances[j] = (get_distance(X[i], self.X[j]), self.y[j])
            distances.sort()

            knn_distances = [distances[j][0] for j in range(self.n_neighbors)]
            weights = get_weights(knn_distances)
            label_counter = defaultdict(float)
            for j in range(self.n_neighbors):
                label_counter[distances[j][1]] += weights[j]
            max_count = 0.0
            for label, count in label_counter.items():
                if count > max_count:
                    max_count = count
                    y[i] = label
        return y

# Regression based on k-nearest neighbors
class KNeighborsRegressor(KNeighbors):
    def __init__(self, n_neighbors=5, weights='uniform', p=2, metric='minkowski', normalization='none'):
        KNeighbors.__init__(self, n_neighbors, weights, p, metric, normalization)

    # Predict the output value for the provided data
    def predict(self, X):
        assert isinstance(X, np.ndarray) and len(X.shape) == 2
        assert X.shape[1] == self.X.shape[1]
        get_weights  = getattr(self, '_' + self.weights)
        get_distance = getattr(self, '_' + self.metric)
        normalize    = getattr(self, '_' + self.normalization)
        X = normalize(X)
        y = np.array([0 for i in range(X.shape[0])])
        for i in range(X.shape[0]):
            distances = [0 for _ in range(self.X.shape[0])]
            for j in range(self.X.shape[0]):
                distances[j] = (get_distance(X[i], self.X[j]), self.y[j])
            distances.sort()

            knn_distances = [distances[j][0] for j in range(self.n_neighbors)]
            weights = get_weights(knn_distances)
            for j in range(self.n_neighbors):
                y[i] += (weights[j] * distances[j][1])
            y[i] /= sum(weights)
        return y

# Leave-one-out cross-validation using X as training data and y as target values
def cross_val_score(clf, X, y):
    assert isinstance(clf, KNeighborsClassifier) or isinstance(clf, KNeighborsRegressor)
    assert isinstance(X, np.ndarray) and isinstance(y, np.ndarray)
    assert X.shape[0] == y.shape[0]
    if isinstance(clf, KNeighborsClassifier):
        iter_score = lambda y, ey: 1 if y[0] == ey[0] else 0
        finalize   = lambda score, n: score * 100 / n
    else:
        iter_score = lambda y, ey: (y[0] - ey[0])**2
        finalize   = lambda score, n: math.sqrt(score / n)
    score = 0
    for i in range(X.shape[0]):
        X_train = np.concatenate((X[:i], X[i+1:]))
        y_train = np.concatenate((y[:i], y[i+1:]))
        X_test  = np.array([X[i]])
        y_test  = np.array([y[i]])
        clf.fit(X_train, y_train)
        score += iter_score(y_test, clf.predict(X_test))
    return finalize(score, X.shape[0])
