# Produce a graph to compare the various normalization method for KNeighborsRegressor

import arff
import matplotlib.pyplot as plt
import numpy as np
import KNeighbors as kn

with open('autos.arff') as file:
    dataset_autos = arff.load(file)

X_autos, y_autos = [], []
for data in dataset_autos['data']:
    if not None in data:
        X_autos.append([data[0]] + data[8:13] + [data[15]] + data[17:24] + [data[25]])
        y_autos.append(data[24])
X_autos = np.array(X_autos).astype(float)
y_autos = np.array(y_autos).astype(float)

x = [n for n in range(1, 100+1, 1)]
for normalization in ('none', 'zscore', 'minmax'):
    y = []
    for n in range(1, 100+1, 1):
        clf_autos = kn.KNeighborsRegressor(n_neighbors=n,
                                           weights='distance',
                                           metric='minkowski',
                                           normalization=normalization)
        y.append(kn.cross_val_score(clf_autos, X_autos, y_autos))
    plt.plot(x, y, label=normalization)
    
plt.xlabel('K Value')
plt.ylabel('RMSE')
plt.legend()
plt.show()
