# Produce a graph to compare the various distance metric for KNeighborsClassifier

import arff
import matplotlib.pyplot as plt
import numpy as np
import KNeighbors as kn

with open('ionosphere.arff') as file:
    dataset_ionosphere = arff.load(file)

X_ionosphere = np.array([data[:-1] for data in dataset_ionosphere['data']])
y_ionosphere = np.array([data[-1] for data in dataset_ionosphere['data']])

p = 32
x = [n for n in range(1, 100+1, 1)]
for i in range(10):
    y = []
    for n in range(1, 100+1, 1):
        clf_ionosphere = kn.KNeighborsClassifier(n_neighbors=n,
                                                 weights='distance',
                                                 p=p,
                                                 metric='minkowski')
        y.append(kn.cross_val_score(clf_ionosphere, X_ionosphere, y_ionosphere))
    plt.plot(x, y, label='p='+str(p))
    p /= 2

plt.xlabel('K Value')
plt.ylabel('Accuracy')
plt.legend()
plt.show()
