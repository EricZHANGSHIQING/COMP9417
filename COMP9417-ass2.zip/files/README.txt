DATASETS
ionosphere.arff
autos.arff

IMPLEMENTATION FILE
KNeighbors.py

TEST FILE                           RESULT FILE
KNC-choice_of_k.py                  KNC-choice_of_k.png
KNC-choice_of_distance_metric.py    KNC-choice_of_distance_metric.png
KNC-choice_of_normalization.py      KNC-choice_of_normalization.png
KNC-choice_of_weight.py             KNC-choice_of_weight.png
KNR-choice_of_k.py                  KNR-choice_of_k.png
KNR-choice_of_distance_metric.py    KNR-choice_of_distance_metric.png
KNR-choice_of_normalization.py      KNR-choice_of_normalization.png
KNR-choice_of_weight.py             KNR-choice_of_weight.png

Notes:
*KNC -> KNeighborsClassifier
*KNR -> KNeighborsRegressor
*Each test file can simply be run to generate the graph in the result file.