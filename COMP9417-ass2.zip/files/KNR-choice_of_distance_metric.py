# Produce a graph to compare the various distance metric for KNeighborsRegressor

import arff
import matplotlib.pyplot as plt
import numpy as np
import KNeighbors as kn

with open('autos.arff') as file:
    dataset_autos = arff.load(file)

X_autos, y_autos = [], []
for data in dataset_autos['data']:
    if not None in data:
        X_autos.append([data[0]] + data[8:13] + [data[15]] + data[17:24] + [data[25]])
        y_autos.append(data[24])
X_autos = np.array(X_autos).astype(float)
y_autos = np.array(y_autos).astype(float)

p = 32
x = [n for n in range(1, 100+1, 1)]
for i in range(10):
    y = []
    for n in range(1, 100+1, 1):
        clf_autos = kn.KNeighborsRegressor(n_neighbors=n,
                                           weights='distance',
                                           p=p,
                                           metric='minkowski')
        y.append(kn.cross_val_score(clf_autos, X_autos, y_autos))
    plt.plot(x, y, label='p='+str(p))
    p /= 2

plt.xlabel('K Value')
plt.ylabel('RMSE')
plt.legend()
plt.show()
